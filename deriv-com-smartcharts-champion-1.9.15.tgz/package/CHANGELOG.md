## [1.9.15](https://github.com/deriv-com/deriv-smartcharts/compare/v1.9.14...v1.9.15) (2026-06-18)


### ♻️ 	 Chores

* **deps-dev:** bump shell-quote from 1.8.3 to 1.8.4 ([9e87149](https://github.com/deriv-com/deriv-smartcharts/commit/9e871498e2f5091b88e6014b2e22747f98ee6a1c))
* **deps-dev:** bump shell-quote from 1.8.3 to 1.8.4 ([d56f96c](https://github.com/deriv-com/deriv-smartcharts/commit/d56f96cefb90988aa58f1ca303b3081cb013e582))
* **deps:** update webpack-dev-server and other dependencies ([a7cbe16](https://github.com/deriv-com/deriv-smartcharts/commit/a7cbe1674e164dca782a7e5ab49d3c2645cd7f52))
* **deps:** update webpack-dev-server and other dependencies ([a92ea1b](https://github.com/deriv-com/deriv-smartcharts/commit/a92ea1be082699f62966cefabc791f996dc48c6b))


### ⚙️ 	 Continuous Integrations

* add qa-checklist workflow (checkmaite) ([#244](https://github.com/deriv-com/deriv-smartcharts/issues/244)) ([8339a89](https://github.com/deriv-com/deriv-smartcharts/commit/8339a898ceea484b02ddde0403f8c62db208eb51))


### 🐛 	 Bug Fixes

* drawing-tools lifecycle (load timing, symbol switch sync, contract-details chart isolation) ([#243](https://github.com/deriv-com/deriv-smartcharts/issues/243)) ([89e516e](https://github.com/deriv-com/deriv-smartcharts/commit/89e516e51d2f787af7d58a1d9f436d4313c1387a))
